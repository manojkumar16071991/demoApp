import * as React from 'react'
import messaging from '@react-native-firebase/messaging'
import firebase from '@react-native-firebase/app'
import { View, Text, Platform, AsyncStorage } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import FirstPage from './src/screens/FirstPage';
import SecondPage from './src/screens/SecondPage';
import ThirdPage from './src/screens/ThirdPage';
const Stack = createStackNavigator();
const iosConfig = {
  clientId: '696686808309-j9vt8si4f0ivo1e902no496d1o9athnp.apps.googleusercontent.com',
  appId: '1:696686808309:ios:984f330893fa1b8f6b89bc', //diff from Android
  apiKey: 'AIzaSyDicidsPKii4MAE7hrQQO4lliRCRSVvrUE', //diff from Android
  databaseURL: 'https://jitt-entertainment-d26e0.firebaseio.com',
  storageBucket: 'jitt-entertainment-d26e0.appspot.com',
  messagingSenderId: '696686808309',
  projectId: 'jitt-entertainment-d26e0',
}
const androidConfig = {
  clientId: '252142781999-dgi6055u5n5261227vi6g2t5gka0shga.apps.googleusercontent.com',
  appId: '1:252142781999:android:604c753abb56bd8b5928da', //diff from iOS
  apiKey: 'AIzaSyBhZ0UFg08IrM_JKyPl1Uc_x4_cu-fLk_s', //diff from iOS
  databaseURL: 'https://fbnn-59092.firebaseio.com',
  storageBucket: 'fbnn-59092.appspot.com',
  messagingSenderId: '252142781999',
  projectId: 'fbnn-59092',
}

if (!firebase.apps.length) {
  firebase.initializeApp(Platform.OS == 'ios' ? iosConfig : androidConfig)
}

export default class App extends React.Component {
  async componentDidMount() {
    this.checkPermission()
  }

  async checkPermission() {
    const enabled = await messaging().hasPermission()
    console.log('check enabled for push or not ', enabled)
    let fcmToken = await AsyncStorage.getItem('fcmToken')
    if (enabled != -1) {
      if (!fcmToken) this.getToken()
      console.log("enabled get fcmToken : ", fcmToken)
    } else {
      this.requestPermission()
    }
  }

  async requestPermission() {
    await messaging().requestPermission({
      alert: true,
      announcement: true,
      badge: true,
      sound: true
    })
      .then(succsess => {
        this.getToken()
        console.log("successss")
      })
      .catch(err => {
        console.log("error...", err)
      })
  }

  async getToken() {
    try {
      const enabled = await messaging().hasPermission()
      if (!enabled) {
        await messaging().requestPermission()
      }
      messaging()
        .getToken()
        .then(token => {
          AsyncStorage.setItem("fcmToken", token)
        })
      const fcmToken = await messaging().getToken()
      if (fcmToken) {
        console.log("got fcmToken : ", fcmToken)
        this.setState({ fcmToken })
        return fcmToken
      }
    } catch (error) {
      console.warn('notification token error : ', error)
    }
  }

  render() {
    return (
      <NavigationContainer>
      <Stack.Navigator initialRouteName="FirstPage">
        <Stack.Screen
          name="FirstPage"
          component={FirstPage}
          options={{
            title: 'Login', //Set Header Title
            headerStyle: {
              backgroundColor: '#f4511e', //Set Header color
            },
            headerTintColor: '#fff', //Set Header text color
            headerTitleStyle: {
              fontWeight: 'bold', //Set Header text style
            },
          }}
        />
        <Stack.Screen
          name="SecondPage"
          component={SecondPage}
          options={{
            title: 'Record', //Set Header Title
            headerStyle: {
              backgroundColor: 'green', //Set Header color
            },
            headerTintColor: '#fff', //Set Header text color
            headerTitleStyle: {
              fontWeight: 'bold', //Set Header text style
            },
          }}
        />
        <Stack.Screen
          name="ThirdPage"
          component={ThirdPage}
          options={{
            title: 'Home', //Set Header Title
            headerStyle: {
              backgroundColor: 'green', //Set Header color
            },
            headerTintColor: '#fff', //Set Header text color
            headerTitleStyle: {
              fontWeight: 'bold', //Set Header text style
            },
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
    )
  }
}