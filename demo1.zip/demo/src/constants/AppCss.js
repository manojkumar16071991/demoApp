import { StyleSheet } from 'react-native';

const AppCss = StyleSheet.create({
    containerLogin: {
        flex: 2,
        justifyContent: "center",
        // alignItems: "center",
        backgroundColor: "#F5FCFF"
    },
    container: { flex: 1 },
    input: {
      margin: 15,
      height: 40,
      borderColor: "black",
      borderWidth: 1
    },
    submitButton: {
      backgroundColor: "black",
      padding: 10,
      margin: 15,
      alignItems: "center",
      height: 40
    },
    submitButtonText: {
      color: "white"
    }
  });

  export default AppCss