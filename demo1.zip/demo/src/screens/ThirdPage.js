import * as React from 'react';
import { View, Text, SafeAreaView, AsyncStorage, TouchableOpacity, StyleSheet } from 'react-native';
import styles from './../constants/AppCss'
const ThirdPage = ({ route, navigation }) => {

  let [data, setData] = React.useState(null)

  React.useEffect(() => {
    const getToken = async () => {
      try {
        let userData = await AsyncStorage.getItem("userData");
        let data = JSON.parse(userData);
        setData(data)
      } catch (error) {
        console.log("Something went wrong", error);
      }
    }
    getToken();
  }, [])
  return (
    <SafeAreaView style={styles.container}>
      <View style={{ flex: 1, padding: 16 }}>
        <Text> Hello : {data ? data.email : null}</Text>
        <Text> Password : {data ? data.password : null}</Text>
        <Text> Phone : {data ? data.phone : null}</Text>
      </View>
      <TouchableOpacity style={styles.submitButton} onPress={() => navigation.navigate("SecondPage")}>
        <Text style={styles.submitButtonText}>Check Details</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.submitButton} onPress={() => navigation.navigate("FirstPage")}>
        <Text style={styles.submitButtonText}>Logout</Text>
      </TouchableOpacity>

    </SafeAreaView>
  );
}



export default ThirdPage;