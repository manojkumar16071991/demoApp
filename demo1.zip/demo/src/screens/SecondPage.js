import React, { Component } from 'react'
import { ScrollView, SafeAreaView ,View, Text,StyleSheet} from 'react-native';

class SecondPage extends Component {
    state = {
        data: []
    }
    componentDidMount = () => {
        fetch('https://jsonplaceholder.typicode.com/posts', {
            method: 'GET'
        })
            .then((response) => response.json())
            .then((responseJson) => {
                console.log(responseJson);
                this.setState({
                    data: responseJson
                })
            })
            .catch((error) => {
                console.error(error);
            });
    }
    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <ScrollView>
                    <View>
                        {
                            this.state.data.map((item,index) => {
                                return <View  key = {index} style = {styles.container}>
                                    <Text style={styles.text}>
                                        User Id : {item.userId}
                                    </Text>
                                    <Text style={styles.text1}>
                                        Title : {item.title}
                                    </Text>
                                    <Text style={styles.text2}>
                                        Description: {item.body}
                                    </Text>
                                </View>

                            })
                        }

                    </View>
                </ScrollView>
            </SafeAreaView>
        )
    }
}

const styles = StyleSheet.create({
    container : { margin: 5, backgroundColor: "yellow", padding: 20, borderRadius: 5 },
    text : { color: "red", fontSize: 20, paddingBottom: 5 },
    text1 : { color: "green", fontSize: 20, paddingBottom: 5 },
    text2 : { color: "blue", fontSize: 20, paddingBottom: 5 },
})
export default SecondPage