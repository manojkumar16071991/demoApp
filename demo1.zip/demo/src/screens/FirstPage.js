import * as React from 'react';
import { Text, TextInput, TouchableOpacity, View, AsyncStorage, Alert } from "react-native";
import styles from './../constants/AppCss'

const FirstPage = ({ navigation }) => {
    let [email, setEmail] = React.useState("")
    let [password, setPassword] = React.useState("")
    let [phone, setPhone] = React.useState("")
    let [user, setUser] = React.useState({})

    const validateEmail = (email) => {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email.toLowerCase());
    }
    const validatePassword = (password) => {
        const mediumRegex = new RegExp("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");
        return mediumRegex.test(password);
    }
    const phoneValidate = (phone) => {
        const mediumRegex = new RegExp("^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$");
        return mediumRegex.test(phone);
    }




    const handleSubmit = () => {
        if (email == "" || email == null || email == undefined) {
            Alert.alert("Email is Empty!")
        } else if (phone == "" || phone == null || phone == undefined) {
            Alert.alert("Phone number is Empty!")
        } else if (password == "" || password == null || password == undefined) {
            Alert.alert("Password is Empty!")
        } else  {
            
            if (validateEmail(email) === false) {
                Alert.alert("Please enter right email.")
               

            }  else if(validatePassword(password)=== false) {
                Alert.alert("Please enter one special character, One Capital letter and number!")
            } else if(phoneValidate(phone)=== false){
                Alert.alert("Please enter valid phone number!")

            }else{
                setEmail("")
                setPassword("")
                setPhone("")
                console.log("Logingdslkfj", validateEmail(email))
                const user = { email: email, "phone": phone, "password": password }
                setUser(user)
                storeToken(user)
                console.log(user)
                navigation.navigate("ThirdPage")
               
            }
        }
    }
    const storeToken = async (user) => {
        try {
            await AsyncStorage.setItem("userData", JSON.stringify(user));
        } catch (error) {
            console.log("Something went wrong", error);
        }
    }

    return (
        <View style={styles.containerLogin}>
            <TextInput
                style={styles.input}
                underlineColorAndroid="transparent"
                placeholder="Email"
                placeholderTextColor="black"
                autoCapitalize="none"
                onChangeText={(text) => setEmail(text)}
                value={email}
            />

            <TextInput
                style={styles.input}
                underlineColorAndroid="transparent"
                placeholder="Phone number"
                placeholderTextColor="black"
                autoCapitalize="none"
                onChangeText={(text1) => setPhone(text1)}
                value={phone}
            />

            <TextInput
                style={styles.input}
                underlineColorAndroid="transparent"
                placeholder="Password"
                placeholderTextColor="black"
                autoCapitalize="none"
                secureTextEntry={true}
                onChangeText={(text2) => setPassword(text2)}
                value={password}
            />
            <TouchableOpacity
                style={styles.submitButton}
                onPress={() => handleSubmit()}
            >
                <Text style={styles.submitButtonText}> Submit </Text>
            </TouchableOpacity>
        </View>
    );

}


export default FirstPage;